#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <iostream>
#include <fstream> 
#include <sstream>
#include <vector>
#include <time.h>

#include "CERES.h"

#define LAYER_SIZE 1 

using namespace std;

void Ceres_GenResultFile (Ceres &ceres, vector<Task*> task_to_handle, unsigned times);

int main(int argc,char* argv[])
{
	if (argc!=5)
	{
		cerr<<"Usage: ./ceres_exe <numbers> <envir_type> <dot_protect> <sig_protect>"<<endl;
		return -1;
	}

	istringstream ss(argv[1]);
	int RUNsize;
	if (!(ss>>RUNsize)||!(RUNsize>0))
	{	
		cerr<<"Usage: ./ceres_exe <numbers> <envir_type> <dot_protect> <sig_protect>"<<endl;
		cerr<<"Invalid number "<<argv[1]<<endl;
		return -1;
	}

	string envir(argv[2]);
	istringstream dicc(argv[2]);
	int env_type;
	//if ((envir!="1")&&(envir!="3")&&(envir!="5"))
	if (!(dicc>>env_type)||!(env_type>0))
	{
		cerr<<"Usage: ./ceres_exe <numbers> <envir_type> <dot_protect> <sig_protect>"<<endl;
		cerr<<"Invalid type "<<argv[2]<<endl;
		return -1;
	}

	istringstream ss1(argv[3]);
	istringstream ss2(argv[4]);
	float dot_protect;
	float sig_protect;
	if (!(ss1>>dot_protect)||!(dot_protect>0))
	{	
		cerr<<"Usage: ./ceres_exe <numbers> <envir_type> <dot_protect> <sig_protect>"<<endl;
		cerr<<"Invalid number "<<argv[3]<<endl;
		return -1;
	}

	if (!(ss2>>sig_protect)||!(sig_protect>0))
	{	
		cerr<<"Usage: ./ceres_exe <numbers> <envir_type> <dot_protect> <sig_protect>"<<endl;
		cerr<<"Invalid number "<<argv[4]<<endl;
		return -1;
	}
		
	srand(time(NULL));
	
	Ceres my_ceres(envir);
	/****************************
		User Interface
			- create TaskData
			- setting TaskData Value
			- create task(&task_kernel, instruction_num, reliability, &taskdata)
			- push every task into task_to_handle
			- use my_ceres.robustComputing(task_to_handle) 
				or  Ceres_GenResultFile(my_ceres, task_to_handle, run times);
			
			- taskgraph looks like
	****************************/
	int task_num = 6;

	/*--------------------
		create TaskData
	--------------------*/
	TaskData* tds[task_num];
	for (int i = 0; i < task_num; ++i)
		tds[i] = new TaskData();
	
	vector<Task*> task_to_handle[1];//nine stages!!!
	/*---------------------------------------------------------------------
		create task(&task_kernel, instruction_num, reliability, &taskdata)
	---------------------------------------------------------------------*/
	Task* tasks[task_num];
	//-------------------//
	printf("Set values \n");

	//layer 1 , two input using 18000, five use 45000
	tasks[0] = new Task(&task6_kernel, 760  , dot_protect , tds[0], 1);
	tasks[1] = new Task(&task6_kernel, 761  , dot_protect , tds[1], 1);
	tasks[2] = new Task(&task6_kernel, 762  , dot_protect , tds[2], 1);
	tasks[3] = new Task(&task6_kernel, 763  , dot_protect , tds[3], 1);
	tasks[4] = new Task(&task6_kernel, 764  , dot_protect , tds[4], 1);
	tasks[5] = new Task(&task6_kernel, 765  , dot_protect , tds[5], 1);
	
		//layer 1
	for(unsigned int k=0;k<6;++k)
		task_to_handle[0].push_back(tasks[k]);
//---------------------------error_free result------------------------------//
	ofstream err_free_file;
	err_free_file.open("./Result/error_free_result.txt", ios::out|ios::trunc);
	
	// put error_free result into m_ceres in original taskdata
	printf("Computimg error_free result on core_id 0 ...\n");

	err_free_file<<"Error_Free Result :\n";
	
for (unsigned layer_count = 0 ; layer_count < LAYER_SIZE ; layer_count++){
	
     //printf("layer_count ... %d \n" , layer_count);

	err_free_file<<"================================================"<<endl;
	err_free_file<<" Stages "<< layer_count <<endl;
	
	unsigned num_task = task_to_handle[layer_count].size();

	for (unsigned t_th = 0; t_th < num_task; ++t_th){
     //printf("t_th ... %d \n" , t_th);

		err_free_file<<"  task_"<<t_th<<"\n"<<"         ";

		Task* task_ptr = task_to_handle[layer_count].at(t_th);

     //printf("t_th ... %d \n" , t_th);
		( *(task_ptr->m_pthread_func_ptr) )( (void*) task_ptr->m_task_data_ptr );
     //printf("t_th ... %d \n" , t_th);
		vector<Element> err_free = task_ptr->m_task_data_ptr->m_ceres;
		
    //printf("t_th ... %d \n" , t_th);
		//printf("err_free is %d \n", err_free.size() ) ;

		for (unsigned i = 0; i < err_free.size(); ++i){
			err_free_file<<err_free.at(i)._num<<" ";
		}		
		
		// ho
		(task_ptr->m_task_data_ptr->m_buffer) = task_ptr->m_task_data_ptr->m_ceres ;

		err_free_file<<"\n";

		//reset m_ceres
		task_ptr->m_task_data_ptr->m_ceres.clear();
	}
	//err_free_file<<"\n \n";
}
	err_free_file.close();

//---------------------------error_free result------------------------------//

	string exp_type_1 = "Random" ;  
	//string exp_type_2 = "Random_" ;

cout<<"Error free ends... "<<endl<<endl;

ofstream final_file; 
final_file.open("./Result/final_result.txt", ios::out|ios::app);

cout<<"===========================TOTAL RUN STARTS...============================="<<endl;
//////////THIS i is RUN SIZE!!!!/////////////////////
for(size_t i = 0 ; i < RUNsize ;i++){
	printf("First layer \n");
//	
	if(exp_type_1 == "Random")
		my_ceres.GG_robustCombuting(task_to_handle[0]);
	else
		my_ceres.robustComputing_modify(task_to_handle[0]);
	
	final_file<<"Count "<<i<<endl;

//==================output_file===============================================//
cout<<"===========================Start output file...============================="<<endl;
	for (unsigned layer_count =0 ; layer_count < LAYER_SIZE ; layer_count++){

		final_file<<"================================================"<<endl;
		final_file<<" Stages "<<layer_count<<endl;
		
		for (unsigned t_th = 0; t_th < task_to_handle[layer_count].size(); ++t_th){
			final_file<<"  task_" <<t_th<<"\n"<<"         ";
			vector<Element> final = task_to_handle[layer_count].at(t_th)->m_task_data_ptr->m_final;
			for (unsigned i = 0; i < final.size(); ++i){
				final_file<<final.at(i)._num<<" ";
			}
				final_file<<"\n";
		}
			final_file.flush();	
	}	
}
final_file.close();
cout<<"===========================Finiah...============================="<<endl;
	//return (0);
}



typedef vector<float> result;

void Ceres_GenResultFile (Ceres &ceres, vector<Task*> task_to_handle, unsigned times){
	unsigned T = task_to_handle.size();

	/*-------------------
	   Error Free Result
	--------------------*/
	ofstream err_free_file;
	err_free_file.open("./Result/error_free_result.txt", ios::out|ios::trunc);
	
	// put error_free result into m_ceres in original taskdata
	printf("Computimg error_free result on core_id 0 ...\n");

	err_free_file<<"Error_Free Result :\n";

	for (unsigned t_th = 0; t_th < T; ++t_th){

		err_free_file<<" task_"<<t_th<<"\n"<<"         ";

		Task* task_ptr = task_to_handle.at(t_th);

		// call kernel function
		( *(task_ptr->m_pthread_func_ptr) )( (void*) task_ptr->m_task_data_ptr );
		vector<Element> err_free = task_ptr->m_task_data_ptr->m_ceres;

		for (unsigned i = 0; i < err_free.size(); ++i){
			err_free_file<<err_free.at(i)._num<<" ";
		}
		err_free_file<<"\n";

		//reset m_ceres
		task_ptr->m_task_data_ptr->m_ceres.clear();
	}
	err_free_file.close();

	/*-------------------
	   	Final Result
	--------------------*/
	ofstream final_file; 
	final_file.open("./Result/final_result.txt", ios::out|ios::app);

	for (unsigned t = 1; t <= times; ++t)
	{
		// original senior's 
		//ceres.robustComputing(task_to_handle);
		// original senior's modify 
		//ceres.robustComputing_modify(task_to_handle);
		// ours NMR and NMR_1,3,5
		ceres.GG_robustCombuting(task_to_handle);
		

		// final_file<<" time "<<t<<":\n";

		for (unsigned t_th = 0; t_th < T; ++t_th){

			final_file<<"  task "<<t_th<<"\n"<<"         ";

			vector<Element> final = task_to_handle.at(t_th)->m_task_data_ptr->m_final;

			for (unsigned i = 0; i < final.size(); ++i){
				final_file<<final.at(i)._num<<" ";
			}
			final_file<<"\n";
		}
		final_file<<"\n";
		final_file.flush();
	}	
	final_file.close();
}


